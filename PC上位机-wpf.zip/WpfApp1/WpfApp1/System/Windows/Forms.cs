﻿namespace System.Windows
{
    internal class Forms
    {
        public static object DialogResult { get; internal set; }
    }
}